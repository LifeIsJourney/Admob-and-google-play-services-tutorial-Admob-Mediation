# Unity Ads Adapter plugin for Google Mobile Ads SDK for Unity 3D Changelog

## 1.0.0

- First release!
- Supports Android adapter version 2.1.2.0.
- Supports iOS adapter version 2.1.2.0.
